package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MonarchAdapter extends RecyclerView.Adapter<MonarchAdapter.ViewHolder> {

    private final LayoutInflater inflater; //
    private final List<Monarch> monarchs; // п\

    public MonarchAdapter(Context context, List<Monarch> monarchs) {
        this.inflater = LayoutInflater.from(context);
        this.monarchs = monarchs;
    }

    @Override
    public MonarchAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MonarchAdapter.ViewHolder holder, int position) {
        Monarch monarch = monarchs.get(position);
        holder.monarchView.setImageResource(monarch.getMonarchResource());
        holder.nameView.setText(monarch.getName());
        holder.monarchDescriptionView.setText(monarch.getMonarchDescription());
        holder.Achivments.setText(monarch.getAchivments());
    }

    @Override
    public int getItemCount() {
        return monarchs.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView monarchView;
        final TextView nameView, monarchDescriptionView, Achivments;

        ViewHolder(View view) {
            super(view);
            monarchView = view.findViewById(R.id.monarchResource);
            nameView = view.findViewById(R.id.name);
            monarchDescriptionView = view.findViewById(R.id.monarchDescription);
            Achivments = view.findViewById(R.id.Achivments);
        }
    }
}