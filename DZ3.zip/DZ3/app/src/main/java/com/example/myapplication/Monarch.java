package com.example.myapplication;

public class Monarch {

    private String name;
    private String monarchDescription;
    private int monarchResource;
    private String Achivments;

    public Monarch(String name, String monarchDescription, int monarchResource, String Achivments) {
        this.name = name;
        this.monarchDescription = monarchDescription;
        this.monarchResource = monarchResource;
        this.Achivments = Achivments;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMonarchDescription() {
        return monarchDescription;
    }

    public void setMonarchDescription(String monarchDescription) {
        this.monarchDescription = monarchDescription;
    }

    public int getMonarchResource() {
        return monarchResource;
    }

    public void setMonarchResource(int MonarchResource) {
        this.monarchResource = monarchResource;
    }

    public String getAchivments() {
        return Achivments;
    }

    public void setAchivments(String Achivments) {
        this.Achivments = Achivments;
    }
}
